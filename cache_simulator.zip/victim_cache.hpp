
class VictimCache {
private:
    int size;
    std::deque<CacheBlock> blocks; // Fully-associative victim cache

public:
    VictimCache(int size) : size(size) {}

    // Search for a block in victim cache
    bool search(unsigned int address) {
        for (auto it = blocks.begin(); it != blocks.end(); ++it) {
            if (it->address == address) {
                // Move block to front if found
                CacheBlock foundBlock = *it;
                blocks.erase(it);
                blocks.push_front(foundBlock);
                return true;
            }
        }
        return false;
    }

    // Add a block to victim cache, evict if necessary
    void addBlock(CacheBlock block) {
        if (blocks.size() >= size) {
            blocks.pop_back(); // Evict LRU block
        }
        blocks.push_front(block); // Add new block
    }
};
